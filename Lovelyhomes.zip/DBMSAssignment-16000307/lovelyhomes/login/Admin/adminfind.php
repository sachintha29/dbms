<html>

<head>
<title> Administrator find </title>
<link rel="stylesheet" type="text/css" href="designdata.css" />
</head>

<body>
<body background="furniture.jpg">
    <header>
        <div class = "Heading"> <! Box containing the picture>

            <img src="" style="vertical-align: middle" width= "100%" height="80px" />
            <p class="absolute_text">Lovely Homes</a></p>

    </header> </div>

    <div class="menu">  <! This is the box containing the menu>

            <aside><a href="../../Mainpage.php" target="_self"><font color="white">Home</font></a></aside>
            <aside><a href="../../About.php" target="_self"><font color="white">About</font></a></aside>
            <aside><a href="../../Contact.php" target="_self"><font color="white">Contact</font></a></aside>
			<aside><a href="newAdmin.php" target="_self"><font color="white">Back</font></a></aside>
    </div>


<?php
$id= $_POST['id'];

include 'connection.php';

//Select Data
$sql1 ="SELECT * FROM admin ";
$sql ="SELECT * FROM admin where ID='$id'";
$result = mysqli_query($conn,$sql);

if(mysqli_num_rows($result)>0){
	//out put data of each row
	while($row =  mysqli_fetch_assoc($result)){
		?>
		
		<table align="center" border="1px">
		<tr><td><b>ID </b> </td><td><b>User Name</b></td><td><b>Password</b></td><td><b>levels</b></td></tr>
		<tr><td><?php echo $id; ?></td>
		<td><?php echo $row["username"]; ?></td>
		<td><?php echo $row["password"]; ?></td>
		<td><?php echo $row["levels"]; ?></td></tr>
		
		</table>
		
		
		<br/><br/>
		<?php
	}
}else{

	
   echo "0 reslut";
}

mysqli_close($conn);

?>
<?php

mysql_connect('localhost','root','');

mysql_select_db('lovelyhomes');
$sql="SELECT * FROM admin";
$records=mysql_query($sql);
?>
<table width="600" border="1" cellspacing="1">
<tr><td><b>ID </b> </td><td><b>User Name</b></td><td><b>Password</b></td><td><b>levels</b></td></tr>
<?php
while($employee=mysql_fetch_assoc($records)){
	echo"<tr>";
	echo"<td>".$employee['ID']."</td>";
	echo"<td>".$employee['username']."</td>";
	echo"<td>".$employee['password']."</td>";
	echo"<td>".$employee['levels']."</td>";
	echo"</tr>";

	
}//end while
?>
</table>

<br>
<br>
<body background="img26.jpg">
<a href="../../Admin.php">back</a>
</body>
</html>












