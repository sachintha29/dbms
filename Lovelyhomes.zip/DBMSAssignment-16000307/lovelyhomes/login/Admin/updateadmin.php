<html>

<head>
<title> Update Administrator </title>
<link rel="stylesheet" type="text/css" href="designdata.css" />
</head>

<body>
<body background="furniture.jpg">
    <header>
        <div class = "Heading"> <! Box containing the picture>

            <img src="" style="vertical-align: middle" width= "100%" height="80px" />
            <p class="absolute_text">Lovely Homes</a></p>

    </header> </div>

    <div class="menu">  <! This is the box containing the menu>

            <aside><a href="../../Mainpage.php" target="_self"><font color="white">Home</font></a></aside>
            <aside><a href="../../About.php" target="_self"><font color="white">About</font></a></aside>
            <aside><a href="../../Contact.php" target="_self"><font color="white">Contact</font></a></aside>
			<aside><a href="newAdmin.php" target="_self"><font color="white">Back</font></a></aside>
    </div>

<?php
$id= $_POST['id'];
$uname= $_POST['user'];
//$pass= $_POST['pass'];

include 'connection.php';

//Update Data
$sql ="UPDATE admin SET username='$uname' WHERE ID='$id'";

if(mysqli_query($conn,$sql)){
  echo "Admin updated successfully";
}else{
  echo "Error:" . $sql . "<br>" . mysqli_error($conn);
}
mysqli_close($conn);
?>

<?php

mysql_connect('localhost','root','');

mysql_select_db('lovelyhomes');
$sql="SELECT * FROM admin";
$records=mysql_query($sql);
?>
<table width="600" border="1" cellspacing="1">
<tr><td><b>ID </b> </td><td><b>User Name</b></td><td><b>Password</b></td><td><b>levels</b></td></tr>
<?php
while($employee=mysql_fetch_assoc($records)){
	echo"<tr>";
	echo"<td>".$employee['ID']."</td>";
	echo"<td>".$employee['username']."</td>";
	echo"<td>".$employee['password']."</td>";
	echo"<td>".$employee['levels']."</td>";

	echo"</tr>";

	
}//end while
?>
</table>
<br>
<br>
<body background="img26.jpg">
<a href="../../Admin.php">back</a>
</body>
</html>
