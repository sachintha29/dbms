<?php
$indx= $_POST['indx1'];

include 'connection.php';

//Delete Data
$sql ="DELETE from client WHERE ClientID='$indx'";
if(mysqli_query($conn,$sql)){
   echo "record deleted successfully";
}else{
   echo "Error:" . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
?>