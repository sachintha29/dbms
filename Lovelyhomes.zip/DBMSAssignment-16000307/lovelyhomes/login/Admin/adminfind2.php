<?php

mysql_connect('localhost','root','');

mysql_select_db('lovelyhomes');
$sql="SELECT * FROM admin";
$records=mysql_query($sql);
?>
<table width="600" border="1" cellspacing="1">
<tr><td><b>ID </b> </td><td><b>User Name</b></td><td><b>Password</b></td></tr>
<?php
while($employee=mysql_fetch_assoc($records)){
	echo"<tr>";
	echo"<td>".$employee['ID']."</td>";
	echo"<td>".$employee['username']."</td>";
	echo"<td>".$employee['password']."</td>";
	echo"</tr>";

	
}//end while
?>
