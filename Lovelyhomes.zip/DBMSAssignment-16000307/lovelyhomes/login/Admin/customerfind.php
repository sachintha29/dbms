<?php
$indx= $_POST['indx'];

include 'connection.php';

//Select Data
$sql1 ="SELECT * FROM client ";
$sql ="SELECT * FROM client where ClientID='$indx'";
$result = mysqli_query($conn,$sql);

if(mysqli_num_rows($result)>0){
	//out put data of each row
	while($row =  mysqli_fetch_assoc($result)){
		?>
		<table align="center" border="1px">
		<tr><td><b>CostomerID</td><td>First Name</td><td>Last Name</td><td>Contact No</td><td>Address</td><td>Email</td><td>District Code</td></b></tr>
		<tr><td><?php echo $indx; ?></td>
		<td><?php echo $row["Client_FName"]; ?></td>
		<td><?php echo $row["Client_LName"]; ?></td>
		<td><?php echo $row["Contact_No"]; ?></td>
		<td><?php echo $row["Address"]; ?></td>
		<td><?php echo $row["Email"]; ?></td>
		<td><?php echo $row["DistrictCode"]; ?></td></tr>
		</table>
		
		
		<br/><br/>
		<?php
	}
}else{
   echo "0 reslut";
}

mysqli_close($conn);
?>