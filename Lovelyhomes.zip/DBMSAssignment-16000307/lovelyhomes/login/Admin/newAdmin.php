<!DOCTYPEhtml >
<head>
<title>Adminstrator Management</title>
<link rel="stylesheet" type="text/css" href="designdata.css" />
</head>

<body>
    <header>
        <div class = "Heading"> <! Box containing the picture>

            <img src="lovelyhomes.jpg" style="vertical-align: middle" width= "100%" height="400px" />
            <p class="absolute_text">Lovely Homes</a></p>

    </header> </div>

    <div class="menu">  <! This is the box containing the menu>

            <aside><a href="../../Mainpage.php" target="_self"><font color="white">Home</font></a></aside>
            <aside><a href="#" target="_self"><font color="white">About</font></a></aside>
            <aside><a href="#" target="_self"><font color="white">Contact</font></a></aside>
			<aside><a href="../Admin.php" target="_self"><font color="white">Back</font></a></aside>
    </div>
    <br/>
    <br/>
<div class= "formorder"> <! This is the box containing the form and the navigation>

    <div class="content"><! This is the box containing the administrator and customer links>
            <div id="Navigation">
		
              
                   <h2><center><font size="5.5px"><u><b href="#" target="_self">Administrator</b></font></center></h2>
				   <ul>
						<li><font size="5px">Admin</font></a></li>
					</ul>
				   

</div>
<h3><u>New Admin</u></h3>
<form name="frm1" action="addadmin.php" method="post">
<div class= "formcontainer">
<fieldset>
<h4>AdminID</h4>
<table>
<tr><td>UserID:</td><td><input type="text" name="id" placeholder="enter (1,2,3 type)" /> </td></tr>
<tr><td>User name:</td><td><input type="text" name="user" /></td></tr>
<tr><td>Password:</td><td><input type="password" name="pass" /></td></tr>
<tr><td>levels:</td><td><input type="text" name="level" /></td><td>0-administrator <br> 1-Manager<br>  2-Salesman</td></tr>
</table>
<br><input type="submit" name="sub" value="Add"></body>


</fieldset>
</div>
</form>

<h3><u>Find Admin Details</u></h3>
<form name="frm3" action="adminfind.php" method="post">
<div class= "formcontainer">
<fieldset>
<h4>Admin ID</h4> 
<input type="text" name="id" value="" placeholder="Enter as 1">
<input type="submit" name="sub" value="search" ></body>
</fieldset>
</div>
</form>


<h3><u>Delete Admin Details</u></h3>
<form name="frm2" action="admindelete.php" method="post">
<div class= "formcontainer">
<fieldset>
<h4>Admin ID</h4> 
<input type="text" name="id">
<input type="submit" name="sub" value="delete" ></body>
</fieldset>
</div>    
</form>
</div>


<h3><u>Update Admin Details</u></h3>
<form action="updateadmin.php" method="post">
<fieldset>
<div class="formcontainer">
<table>
<form action="updateadmin.php" method="post">
<tr><td>User-ID    <td>:-</td> </td><td><input type="text" id="id" name="id" /></td></tr>
<tr><td>User-Name  <td>:-</td></td><td><input type="text" id="user" name="user" /></td></tr>
<tr><td><input type="submit" name="submit" value="update"></td><td><input type="reset" name="reset" value="clear"></td></tr>
</form>
<form action="update1.php" method="post">
<tr><td>User-ID  <td>:-</td></td><td><input type="text" id="id" name="id" /></td></tr>
<tr><td>Password   <td>:-</td></td><td><input type="password" id="pass" name="pass" /></td></tr>
<tr><td><input type="submit" name="submit" value="update"></td><td><input type="reset" name="reset" value="clear"></td></tr>
</form>
<form action="update2.php" method="post">
<tr><td>User-Name  <td>:-</td></td><td><input type="text" id="id" name="id" /></td></tr>
<tr><td>levels  <td>:-</td></td><td><input type="text" id="level" name="level" /></td></tr>
<tr><td><input type="submit" name="submit" value="update"></td><td><input type="reset" name="reset" value="clear"></td></tr>
</form>

</table>
</fieldset>
</div>

	   
		   

</div>
</html>


