<?php

if(isset($_POST['id'])) 
{
	$id=$_POST['id'];
	$query="SELECT * FROM admin WHERE ID='$id"; 
	$search_result=filterTable($query);
}
else{
	$query="SELECT * FROM admin"; 
	$search_result=filterTable($query);
}
function filterTable($query)
{
	$connect=mysqli_connect("localhost","root","","lovelyhomes");
	$filter_Result=mysqli_query($connect,$query);
	return $filter_Result;
}
?>
<html>
<head>
<style>
 table,tr,th,td
 {
	 border:1px solid black
 }

</style>

</head>

<body><form>
<input type="text" name="valueToSearch" placeholder="value">
<input type="text" name="search" value="Filter"><br><br>
<table>
<tr><td>User ID</td><td>Usename</td><td>Password</td>
<?php while($row=mysqli_fetch_array($search_result)):?>
<tr>
   <td><?php echo $row['ID'];?></td>
	<td><?php echo $row['username'];?></td>
	<td><?php echo $row['password'];?></td>
</tr>
<?php endwhile;?> 
</table>
</form>
</body>
</html>









</body>

</html>
