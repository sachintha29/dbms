<html>

<head>
<title>Delete Showrooms </title>
<link rel="stylesheet" type="text/css" href="designdata.css" />
</head>

<body>
    <header>
        <div class = "Heading"> <! Box containing the picture>

            <img src="" style="vertical-align: middle" width= "100%" height="80px" />
            <p class="absolute_text">Lovely Homes</a></p>

    </header> </div>

    <div class="menu">  <! This is the box containing the menu>

            <aside><a href="../../Mainpage.php" target="_self"><font color="white">Home</font></a></aside>
            <aside><a href="../../About.php" target="_self"><font color="white">About</font></a></aside>
            <aside><a href="../../Contact.php" target="_self"><font color="white">Contact</font></a></aside>
			<aside><a href="Showrooms.php" target="_self"><font color="white">Back</font></a></aside>
    </div>

<body background="furniture.jpg">
<?php
$indx= $_POST['district'];

include 'connection.php';

//Delete Data
$sql ="DELETE from showrooms WHERE District='$indx'";
if(mysqli_query($conn,$sql)){
   echo "record deleted successfully";
}else{
   echo "Error:" . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
?>



<?php

mysql_connect('localhost','root','');

mysql_select_db('lovelyhomes');
$sql="SELECT * FROM showrooms";
$records=mysql_query($sql);
?>
<body>
<table width="600" border="1" cellspacing="1">
<tr><td><b>District Code</b> </td><td><b>District</b><td><b>Showroom Address</b></td><td><b>Telephone</b></td></tr>
<?php
while($showroom=mysql_fetch_assoc($records)){
	echo"<tr>";
	echo"<td>".$showroom['Districtcode']."</td>";
	echo"<td>".$showroom['District']."</td>";
	echo"<td>".$showroom['Address']."</td>";
	echo"<td>".$showroom['Telephone']."</td>";
	echo"</tr>";

	
}//end while
?>
</table>
<br>
<br>

</body>
</html>