<!DOCTYPEhtml >
<head>
<title>Showrooms Maganagement</title>
<link rel="stylesheet" type="text/css" href="designdata.css" />
</head>

<body>
    <header>
        <div class = "Heading"> <! Box containing the picture>

            <img src="lovelyhomes.jpg" style="vertical-align: middle" width= "100%" height="400px" />
            <p class="absolute_text">Lovely Homes</a></p>

    </header> </div>

    <div class="menu">  <! This is the box containing the menu>

            <aside><a href="../../Mainpage.php" target="_self"><font color="white">Home</font></a></aside>
            <aside><a href="../../About.php" target="_self"><font color="white">About</font></a></aside>
            <aside><a href="../../Contact.php" target="_self"><font color="white">Contact</font></a></aside>
			<aside><a href="../Admin1.php" target="_self"><font color="white">Back</font></a></aside>
			<aside><a href="../Admin1.php" target="_self"><font color="white">Next</font></a></aside>
    </div>
    <br/>
    <br/>
<div class= "formorder"> <! This is the box containing the form and the navigation>

    <div class="content"><! This is the box containing the administrator and customer links>
            <div id="Navigation">
		
              
                   <h2><center><font size="5.5px"><u><b href="#" target="_self">Showrooms Maganagement</b></font></center></h2>
				   <ul>
						<li><font size="5px">Showrooms Of our company</font></a></li>
					</ul>
				   

</div>
<!---<h3><u>Add new Show room</u></h3>
<form name="frm1" action="addshow.php" method="post">
<div class= "formcontainer">
<fieldset>
<table>
<tr><td>District Code:</td><td><input type="text" name="id" placeholder="enter (1,2,3 type)" /> </td></tr>
<tr><td>District:</td><td><input type="text" name="dist" /></td></tr>
<tr><td>Address:</td><td><input type="text" name="Sadd" /></td></tr>
<tr><td>Telephone:</td><td><input type="text" name="STele" /></td></tr>

</table>
<br><input type="submit" name="sub" value="Add Showroom">
</fieldset>-->
</div>
</form>
<h3><u>Get Find Show rooms Details </u></h3>
<form name="frm2" action="showfind1.php" method="post">
<div class= "formcontainer">
<input type="submit" name="id" value="Search All" >

</div>
</form>
<h3><u>Find Show rooms Details with Furnitures</u></h3>
<form name="frm2" action="showfind2.php" method="post">
<div class= "formcontainer">
<fieldset>
<table>
<tr>
<td>District Code</td><td><input type="text" name="id" placeholder="Enter as 1"></td><td><input type="submit" name="sub" value="search" ></body></td>
</tr>
</table>
<table color="#334456" border="1" cellspacing="1">
<tr><td>District </td><td> District Code</td></tr>
<tr><td>Colombo</td><td>-01</td></tr>	
<tr><td>Gampaha-</td><td>-02</td></tr>				
<tr><td> Kaluthara</td><td>-03</td></tr>				
<tr><td>Kandy</td><td>-04</td></tr>
<tr><td> Mathara</td><td>-05</td></tr>
<tr><td>Rathnapura</td><td>-06</td></tr>
<tr><td>Galle</td><td>-07</td></tr>
<tr><td>Anuradhapura</td><td>-08</td></tr>
<tr><td>Polonnaruwa</td><td>-09</td></tr>
<tr><td>Jaffna</td><td>-10</td></tr>				
</table>  
</fieldset>
</div>
</form>


<h3><u>Delete Showrooms Details</u></h3>
<form name="frm4" action="showdelete1.php" method="post">
<div class= "formcontainer">
<fieldset>
<h4>District Code</h4> 
<input type="text" name="id" placeholder="ex 01,2,3">
<input type="submit" name="sub" value="delete" ></body>
</fieldset>
</div>
</table>
  
</form>
<form name="frm5" action="showdelete2.php" method="post">
<div class= "formcontainer">
<fieldset>
<table>
<tr>

<td>District</td><td><input name="district" placeholder="district name">
</td><td><input type="submit" name="sub" value="delete" ></body></td>
</tr>
</table>
</fieldset>
</div>
</form>


<h3><u>Update Showrooms Details</u></h3>

<fieldset>
<div class="formcontainer">
<table>
<form action="update.php" method="post">
<tr><td>District Code:</td><td><input type="text" name="id" placeholder="1,2,3,4..." /></td></tr>
<tr><td>District:</td><td><input type="text" name="district" placeholder="district name" /></td></tr>
<tr><td><input type="submit" name="text" value="update"></td><td><input type="reset" name="reset" value="clear"></td></tr>
</form>
<form action="update1.php" method="post">
<tr><td>District Code:</td><td><input type="text" name="id" placeholder="1,2,3,4..." /></td></tr>
<tr><td>Address:</td><td><input type="text" name="Sadd" /></td></tr>
<tr><td><input type="submit" name="text" value="update"></td><td><input type="reset" name="reset" value="clear"></td></tr>
</form>
<form action="update2.php" method="post">
<tr><td>District Code:</td><td><input type="text" name="id" placeholder="1,2,3,4..." /></td></tr>
<tr><td>Telephone:</td><td><input type="text" name="Stele" /></td></tr>
<tr><td><input type="submit" name="text" value="update"></td><td><input type="reset" name="reset" value="clear"></td></tr>

</table>
</fieldset>
</div>

	   
		   
</body>
</html>


