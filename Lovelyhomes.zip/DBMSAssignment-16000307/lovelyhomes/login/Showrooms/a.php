<?php



	
mysql_connect('localhost','root','');

mysql_select_db('lovelyhomes');
$sql="SELECT * FROM client,orders WHERE client.ClientID=orders.ClientID AND client.Client_FName='$fname' AND client.Client_LName='$lname'";
$records=mysql_query($sql);
?>


<table width="600" border="1" cellspacing="1">
<tr><td><b>ClientID</b></td>
<td><b>	Client_FName</b></td>	
<td><b>Client_LName	</b></td>
<td><b>	Address</b></td>
<td><b>DistrictCode</b></td>	
<td><b>OrderID</b></td>	
<td><b>	FurnitureID</b></td>	
<td><b>Quantity </b></td> </tr>
<?php
while($client=mysql_fetch_assoc($records)){
	echo"<tr>";
	echo"<td>".$client['ClientID']."</td>";
	echo"<td>".$client['Client_FName']."</td>";
	echo"<td>".$client['Client_LName']."</td>";
	echo"<td>".$client['Address']."</td>";
	echo"<td>".$client['DistrictCode']."</td>";
	echo"<td>".$client['OrderID']."</td>";
	echo"<td>".$client['FurnitureID']."</td>";
	echo"<td>".$client['Quantity']."</td>";
	echo"</tr>";

	
}//end while
?>
<?php
$fname=$_POST["fname"];
$lname=$_POST["lname"];
	
mysql_connect('localhost','root','');

mysql_select_db('lovelyhomes');
$sql="SELECT * FROM client,orders WHERE client.ClientID=orders.ClientID AND client.Client_FName='$fname' AND client.Client_LName=$lname" ;
$records=mysql_query($sql);
?>

<body>
<h1><center><font> Clients details and Order details</font></center></h1>
<body background="img26.jpg">
<table width="800" border="1" cellspacing="1">
<tr><td><b>ClientID</b></td>
<td><b>OrderID</b></td>	
<td><b>	FurnitureID</b></td>
<td><b>	Customer Name</b></td>
<td><b>	Address</b></td>
<td><b>DistrictCode</b></td>	
<td><b>Quantity  </b></td> 
<td><b>Email </b></td> 
<td><b>Contact No </b></td>
 <td><b>Delivary Date </b></td>
 <td><b>Delivary Status(Yes/No) </b></td>
</tr>

<?php
while($order=mysql_fetch_assoc($records)){
	echo"<tr>";
	echo"<td>".$order['ClientID']."</td>";
	echo"<td>".$order['OrderID']."</td>";
	echo"<td>".$order['FurnitureID']."</td>";
	echo"<td>".$order['Client_FName']." ".$order['Client_LName']."</td>";
	echo"<td>".$order['Address']."</td>";
	echo"<td>".$order['DistrictCode']."</td>";
	echo"<td>".$order['Quantity']."</td>";
	echo"<td>".$order['Email']."</td>";
	echo"<td>".$order['Contact_No']."</td>";
	echo"<td>".$order['DeliveryDate']."</td>";
	echo"<td>".$order['Delivarystatus']."</td>";
	echo"</tr>";