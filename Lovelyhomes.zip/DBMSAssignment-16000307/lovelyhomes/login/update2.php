<html>
<head><title>updating custermer details</title>

<link rel="stylesheet" type="text/css" href="designdata.css" />
</head>

<body>
    <header>
        <div class = "Heading"> <! Box containing the picture>

            
            <img src="" style="vertical-align: middle" width= "100%" height="80px" />
            <p class="absolute_text">Lovely Homes</a></p>

    </header> </div>

    <div class="menu">  <! This is the box containing the menu>

            
            <aside><a href="../Mainpage.php" target="_self"><font color="white">Home</font></a></aside>
            <aside><a href="../About.php" target="_self"><font color="white">About</font></a></aside>
            <aside><a href="../Contact.php" target="_self"><font color="white">Contact</font></a></aside>
			<aside><a href="Admin.php" target="_self"><font color="white">Back</font></a></aside>
			<aside><a href="Admin.php" target="_self"><font color="white">Next</font></a></aside>
    </div>
	<body background="furniture.jpg">
<?php
$Cl= $_POST['txtno'];
//$fn= $_POST['txtfn'];
//$ln= $_POST['txtln'];
$add= $_POST['address'];
//$email= $_POST['email'];
//$contact=$_POST['contact'];
//$disct=$_POST['District'];

include 'connection.php';

//Update Data
$sql ="UPDATE client SET Address='$add' WHERE ClientID='$Cl'";

if(mysqli_query($conn,$sql)){
  echo "record updated successfully";
}else{
  echo "Error:" . $sql . "<br>" . mysqli_error($conn);
}
mysqli_close($conn);
?>
<html>

<body>