<html>

<head><title>Go to Admin Page</title>
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<html>
<head>


<title>Login Page</title>
<link rel="stylesheet" type="text/css"  href="style.css">

<link rel="stylesheet" href="designdata.css" />
<link rel="stylesheet" type="text/css" href="style.css">
<link href='https://fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
</head>

<body>
    <header>
        <div class = "Heading"> <! Box containing the picture>

            
            <p class="absolute_text">Lovely Homes</a></p>
</div>
    </header> 

    <div class="menu">  <! This is the box containing the menu>

           
            <aside><a href="../Mainpage.php" target="_self"><font color="white" size="8px">Home   </font></a></aside>
			|||
      
			<aside><a href="login.php" target="_self"><font color="white"size="8px">Back</font></a></aside>
			
	
	</div>
<body background="furniture.jpg"><b><h3>
<?php


$username=$_POST['username'];
$password=$_POST['password'];


$username=stripcslashes($username);
$password=stripcslashes($password);
$username=mysql_real_escape_string($username);
$password=mysql_real_escape_string($password);
mysql_connect("localhost","root","");
mysql_select_db("lovelyhomes");
$result1=mysql_query("select levels from admin where username='$username' and password='$password'")
		or die("Failed to query database".mysql_error());
$result=mysql_query("select * from admin where username='$username' and password='$password'")
		or die("Failed to query database".mysql_error());
$row=mysql_fetch_array($result);
if($row['username']==$username && $row['password']==$password && $row['levels']==0)//levels 0 describe Database Administrator of the company
{
echo"Login Successful!!!<br>Welcome Database Administraor ".$row['username'];
?>
<center><h3><a href="Admin.php"><input type="submit" value="Click here log on Adminstrator page" id="btb" /></a><h3></center>
	<h2 color="blue">You can manage AS Your Own way</h2>
<?php
}
else if($row['username']==$username && $row['password']==$password && $row['levels']==1)//levels 1 describe Manager of the company
{
echo"Login Successful!!!<br>Welcome Manager   ".$row['username'];
?>
<center><h3><a href="Admin1.php"><input type="submit" value="Click here log on Manager page" id="btb" /></a><h3></center>
	<h2 color="blue">You can manage AS Your Own way</h2>
<?php

}
else if($row['username']==$username && $row['password']==$password && $row['levels']==2)//levels 2 describe Salesman of the company
{
echo"Login Successful!!!<br>Welcome Salesman  ".$row['username'];

	
?>
	
	<center><h3><a href="Admin2.php"><input type="submit" value="Click here log on salesman page" id="btb" /></a><h3></center>
	<h2 color="blue">You can manage AS Your Own way</h2>
	
	<?php

}

else{
	echo "Failed to login!,You can't login";
	
	}
?>
<br>
<br>


</body>
</html>
