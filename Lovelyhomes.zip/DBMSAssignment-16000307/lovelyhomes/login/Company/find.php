<?php
		$Id=$_POST['id'];
		$name=$_POST['name'];
		$note=$_POST['description'];
		$price=$_POST['price'];
		$quant=$_POST['quantity'];
		$town=$_POST['district'];
		
		include'connection.php';

		$sql="INSERT INTO companystock(Furniture_ID,furniture_Name,Description,Price,Quantity,DistrictCode) VALUES ('$Id','$name','$note','$price','$quant','$town')";
		if (mysqli_query($conn, $sql)){
	echo "New stock created successfully";
}else
	{
	echo"error:".$sql."<br>".$conn->error;
	}
		
		

?>
<body>

<br>
<br>
<body background="img26.jpg">
<a href="../../Admin.php">back</a>
</body>
</html>