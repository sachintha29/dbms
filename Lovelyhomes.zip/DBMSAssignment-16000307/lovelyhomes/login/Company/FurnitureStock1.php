<!DOCTYPEhtml >
<head>
<title>Company Stock Management</title>
<link rel="stylesheet" type="text/css" href="designdata.css" />
</head>

<body>
    <header>
        <div class = "Heading"> <! Box containing the picture>

            <img src="lovelyhomes.jpg" style="vertical-align: middle" width= "100%" height="450px" />
            <p class="absolute_text">Lovely Homes</a></p>

    </header> </div>

    <div class="menu">  <! This is the box containing the menu>

            
            <aside><a href="../../Mainpage.php" target="_self"><font color="white">Home</font></a></aside>
            <aside><a href="../../About.php" target="_self"><font color="white">About</font></a></aside>
            <aside><a href="../../Contact.php" target="_self"><font color="white">Contact</font></a></aside>
			<aside><a href="../Admin1.php" target="_self"><font color="white">Back</font></a></aside>
			<aside><a href="../Showrooms/Showrooms1.php" target="_self"><font color="white">Next</font></a></aside>
    </div>
    <br/>
    <br/>
<div class= "formorder"> <! This is the box containing the form and the navigation>

    <div class="content"><! This is the box containing the administrator and customer links>
            <div id="Navigation">
		
              
                   <h2><center><font size="5.5px"><u><b href="#" target="_self">Company</b></font></center></h2>
				   <ul>
						<li><font size="5px">Furniture Stock</font></a></li>
					</ul>
				   

</div>
<h3><u>Adding  New  Furniture Item</u></h3>
<form name="frm1" action="additem.php" method="post">
<div class= "formcontainer">
<fieldset>
<h4>New Furniture Item</h4>    
<table>
<tr><td>Furniture Item Code</td><td><input type="text" name="id" placeholder="enter (F0001,F0002...)" /> </td></tr>
<tr><td>Item name</td><td><input type="text" name="name" placeholder=" ex:chair,bed" /> </td></tr>
<tr><td>Item discription</td><td><input type="text" name="description" placeholder="ex:materials,colours" /> </td></tr>
<tr><td>Price</td><td><input type="text" name="price" placeholder="ex:2000,3000" /> </td></tr>
<tr><td>Avaliable quantity</td><td><input type="text" name="quantity" /></td></tr>
<tr><td>Discrictcode</td><td><select name ="district" value="0">
<option> 01</option> <option>02</option><option>03</option><option>04</option><option>05</option> <option>06</option><option>07</option><option>08</option>
</select> </td></tr>
</table>
<br><input type="submit" name="sub" value="Add"></body>


</fieldset>
</div>
</form>

<h3><u>Find Furniture Stock Details</u></h3>
<form name="frm2" action="stockfind.php" method="post">
<div class= "formcontainer">
<fieldset>
<h4>Furniture ID</h4> 
<input type="text" name="id" value="" placeholder="ex:F0001">
<input type="submit" name="sub" value="search" ></body>
</fieldset>
</div>
</form>


<h3><u>Delete Furniture Stock Details</u></h3>
<form name="frm3" action="deletestock.php" method="post">
<div class= "formcontainer">
<fieldset>
<h4>Furniture ID</h4> 
<input type="text" name="id">
<input type="submit" name="sub" value="delete" ></body>
</fieldset>
</div>    
</form>
</div>


<h3><u>Update Furniture Details</u></h3>

<div class="formcontainer">
<fieldset>
<table>
<form action="updatestock.php" method="post">
<tr><td>Furniture Item Code</td><td><input type="text" name="code" placeholder="enter (F0001,F0002...)" /> </td></tr>
<tr><td>Item name</td><td><input type="text" name="name" placeholder=" ex:chair,bed" /> </td><td><input type="submit" name="sub" value="UPDATE"></tr>
</form>
<form action="updatestock1.php" method="post">
<tr><td>Furniture Item Code</td><td><input type="text" name="code" placeholder="enter (F0001,F0002...)" /> </td></tr>
<tr><td>Item discription</td><td><input type="text" name="des" placeholder="ex:materials,colours" /> </td><td><input type="submit" name="sub" value="UPDATE"></tr>
</form>
<form action="updatestock2.php" method="post">
<tr><td>Furniture Item Code</td><td><input type="text" name="code" placeholder="enter (F0001,F0002...)" /> </td></tr>
<tr><td>Price</td><td><input type="text" name="price" placeholder="ex:2000,3000" /> </td><td><input type="submit" name="sub" value="UPDATE"></tr>
</form>
<form action="updatestock3.php" method="post">
<tr><td>Furniture Item Code</td><td><input type="text" name="code" placeholder="enter (F0001,F0002...)" /> </td></tr>
<tr><td>Avaliable quantity</td><td><input type="text" name="quan" /></td><td><input type="submit" name="sub" value="UPDATE"></tr>
</form>
<form action="updatestock4.php" method="post">
<tr><td>Furniture Item Code</td><td><input type="text" name="code" placeholder="enter (F0001,F0002...)" /> </td></tr>
<tr><td>Discrictcode</td><td><select name ="District">
<option> 01</option> <option>02</option><option>03</option><option>04</option><option>05</option> <option>06</option><option>07</option><option>08</option>
<option>09</option><option>10<option>11</option><option>12</option></option></select> </td><td><input type="submit" name="sub" value="UPDATE"></tr>
</form>
</table>
<br></body>

</fieldset>
</div>
</form>
	   
		   

</div>
</html>


