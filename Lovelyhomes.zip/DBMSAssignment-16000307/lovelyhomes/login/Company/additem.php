<!DOCTYPEhtml >
<head>
<title>add Furniture</title>
<link rel="stylesheet" type="text/css" href="designdata.css" />
</head>

<body>
    <header>
        <div class = "Heading"> <! Box containing the picture>

            <img src="" style="vertical-align: middle" width= "100%" height="80px" />
         
            <p class="absolute_text">Lovely Homes</a></p>

    </header> </div>

    <div class="menu">  <! This is the box containing the menu>

            <aside><a href="../../Mainpage.php" target="_self"><font color="white">Home</font></a></aside>
            <aside><a href="../../About.php" target="_self"><font color="white">About</font></a></aside>
            <aside><a href="../../Contact.php" target="_self"><font color="white">Contact</font></a></aside>
			<aside><a href="FurnitureStock.php" target="_self"><font color="white">Back</font></a></aside>
    </div>
	<font size="5px">
<?php
		$Id=$_POST['id'];
		$name=$_POST['name'];
		$note=$_POST['description'];
		$price=$_POST['price'];
		$quant=$_POST['quantity'];
		$town=$_POST['district'];
		
		include'connection.php';

		$sql="INSERT INTO companystock(Furniture_ID,furniture_Name,Description,Price,Quantity,DistrictCode) VALUES ('$Id','$name','$note','$price','$quant','$town')";
		if (mysqli_query($conn, $sql)){
	echo "New stock created successfully";
}else
	{
	echo"error:".$sql."<br>".$conn->error;
	}
		
		

?>
<?php

mysql_connect('localhost','root','');

mysql_select_db('lovelyhomes');
$sql="SELECT * FROM companystock";
$records=mysql_query($sql);
?>
<body>
<table>
<table width="600" border="1" cellspacing="1">
<tr><td><b>Furniture ID </b> </td><td><b>Furniture Name</b></td>
		<td><b>Description</b></td>
		<td><b>Unit Price</b></td><td><b>Available Quantity<b></td>
		<td><b>District Code</b></td></tr>
<?php
while($stock=mysql_fetch_assoc($records)){
	echo"<tr>";
	echo"<td>".$stock['Furniture_ID']."</td>";
	echo"<td>".$stock['furniture_Name']."</td>";
	echo"<td>".$stock['Description']."</td>";
	echo"<td>".$stock['Price']."</td>";
	echo"<td>".$stock['Quantity']."</td>";
	echo"<td>".$stock['DistrictCode']."</td>";
	echo"</tr>";

	
}//end while
?>
</table></font>


<br>
<br>
<body background="img26.jpg">

</body>
</html>