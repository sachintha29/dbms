<?php
		$cid=$_POST['CID'];
		$fname=$_POST['firstname'];
		$lname=$_POST['lastname'];
		$phone=$_POST['number'];
		$address1=$_POST['adderss'];
		$email=$_POST['emailaddress'];
		$FID=$_POST['FurnitureID'];
		$Quantity=$_POST['code'];
		$oid=$_POST['OrderID'];
		
		include'connection.php';

		$sql="INSERT INTO client (ClientID,Client_FName,Client_LName,Contact_No,Address,Email) VALUES ('$cid','$fname','$lname','$phone','$address1','$email');";
		if (mysqli_query($conn, $sql)){
	echo "New record created successfully";
}else
	{
	echo"error:".$sql."<br>".$conn->error;
	}
		$sql1="INSERT INTO orders(OrderID,FurnitureID,Quantity) VALUES ('$oid','$FID','$Quantity')";
		if (mysqli_query($conn, $sql1)){
	echo "New record created successfully";
}else
	{
	echo"error:".$sql."<br>".$conn->error;
	}
		

?>

<!DOCTYPEhtml >
<head>
<title>Lovely homes</title>
<link rel="stylesheet" href="designdata.css" />
</head>

<body>
    <header>
        <div class = "Heading"> <! Box containing the picture>

            <img src="img/lovelyhomes.jpg" style="vertical-align: middle" width= "100%" height="300" />
            <p class="absolute_text">Lovely Homes</a></p>

    </header> </div>

    <div class="menu">  <! This is the box containing the menu>

            <aside><a href="Mainpage.html" target="_self">Home</a></aside>
            <aside><a href="#" target="_self">About</a></aside>
            <aside><a href="#" target="_self">Contact</a></aside>
    </div>
    <br/>
    <br/>
<div class= "formorder"> <! This is the box containing the form and the navigation>

    <div class="content"><! This is the box containing the administrator and customer links>
           <div id="Navigation">
		<ul>
              
                   <li><b href="#" target="_self">Customer</b></li>
             
                   
                   
               	</ul>    
           </div>
<form method="post" action="addCustomer.php">
            <div class= "formcontainer"> <!Box containing the form  >
           <fieldset>
               <legend><h4>Customer Information form</h4></legend>
               <br/>
               <br/>
			   <table>
			   <tr><td>ClientID=</td><td><input name="CID" type="text"  placeholder="C001(type)" />
                </td></tr>
			   <tr><td>First Name=</td><td><input name="firstname" type="text" size="30" value="" placeholder="Enter First Name" />
                </td></tr>
                <tr><td>Last Name=</td><td><input name="lastname" type="text" size="30"  value="" placeholder="Enter Last Name"/>
                </td></tr>
				<tr><td>Address=</td><td><input name="adderss" type="text" value="" placeholder="Enter Address"/>
                </td></tr>
                <tr><td>Email Address=</td><td><input name="emailaddress" type="email" value="" placeholder="Enter Email"/>
                </td></tr>
				<tr><td>Contact Number=</td><td><input name="number" type="tel" value="" placeholder="Enter Telephone Number"/>
                </td></tr>
                </table>
           </fieldset>
        <div/>
    

              

   
            <div class= "formcontainer"> <!Box containing the form  >
           <fieldset>
               <legend><h4>Customer Order form</h4></legend>
               <br/>
               <br/>
			   <table>
			   <tr><td>OrderID=</td><td><input name="OrderID" type="text" size="4" value="" placeholder="001 type" />
                </td></tr>
                <tr><td>Quantity=</td><td><input name="code" type="int"  value="" placeholder="Enter Quantity"/>
                </td></tr>
				<tr><td>FurnitureID=</td><td><input name="FurnitureID" type="text" value="" placeholder="(type=[F0___])"/>
                </td></tr>
               
                </table>
           </fieldset>
        <div/>
    

              <input type="submit" value="CONFIRM">
			 <input name="reset" type="reset" value="Clear">

       </form>
    </div>
</body>
</html>
