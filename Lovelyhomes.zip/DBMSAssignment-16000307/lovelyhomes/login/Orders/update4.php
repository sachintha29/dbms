<html>
<head><title>updating order details</title>

<link rel="stylesheet" type="text/css" href="designdata.css" />
</head>
<body>
    <header>
        <div class = "Heading"> <! Box containing the picture>

            <img src="" style="vertical-align: middle" width= "100%" height="80px" />
            <p class="absolute_text">Lovely Homes</a></p>

    </header> </div>

    <div class="menu">  <! This is the box containing the menu>

            
            <aside><a href="../../Mainpage.php" target="_self"><font color="white">Home</font></a></aside>
            <aside><a href="../../About.php" target="_self"><font color="white">About</font></a></aside>
            <aside><a href="../../Contact.php" target="_self"><font color="white">Contact</font></a></aside>
			<aside><a href="Ordermanage.php" target="_self"><font color="white">Back</font></a></aside>
			<aside><a href="Ordermanage.php" target="_self"><font color="white">Next</font></a></aside>
    </div>
	<body background="furniture.jpg">
<?php

$id= $_POST['id'];
//$cid= $_POST['cid'];
//$fid= $_POST['fid'];
//$quan= $_POST['quan'];
//$date= $_POST['date'];
$choose= $_POST['choose'];
include 'connection.php';

//Update Data
$sql ="UPDATE orders SET Delivarystatus='$choose' WHERE OrderID='$id'";

if(mysqli_query($conn,$sql)){
  echo "Showroom updated successfully";
}else{
  echo "Error:" . $sql . "<br>" . mysqli_error($conn);
}
mysqli_close($conn);
?>


<?php

mysql_connect('localhost','root','');

mysql_select_db('lovelyhomes');
$sql="SELECT * FROM orders";
$records=mysql_query($sql);
?>
<table width="600" border="1" cellspacing="1">
<tr><td><b>Order ID</b></td>
<td><b>Client ID</b></td>
<td><b>Furniture ID</b></td>
<td><b>Quantity</b></td>
<td><b>Delivery Date</b></td>

<td><b>Delivery Status</b></td>
</tr>
<?php
while($order=mysql_fetch_assoc($records)){
	echo"<tr>";
	echo"<td>".$order['OrderID']."</td>";
	echo"<td>".$order['ClientID']."</td>";
	echo"<td>".$order['FurnitureID']."</td>";
	echo"<td>".$order['Quantity']."</td>";
	echo"<td>".$order['DeliveryDate']."</td>";
	echo"<td>".$order['Delivarystatus']."</td>";
		
	echo"</tr>";

	
}//end while
?>
</table>



<br>
<br>

</body>
</html>