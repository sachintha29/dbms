<?php
$id= $_POST['id'];

include 'connection.php';

//Select Data
$sql1 ="SELECT * FROM client ";
$sql ="SELECT * FROM client where ClientID='$id'";
$result = mysqli_query($conn,$sql);

if(mysqli_num_rows($result)>0){
	//out put data of each row
	while($row =  mysqli_fetch_assoc($result)){
		?>
		
		<table align="center" border="1px">
		<tr><td><b> Customer Name</b></td><td><b>Contact No</b></td><td><b>Address</b></td><td><b>Email</b></td><td><b>District Code</td></tr>
		<tr><td><?php echo $row["Client_FName"]; ?>
		        <?php echo $row["Client_LName"]; ?></td>
		<td><?php echo $row["Contact_No"]; ?></td>
		<td><?php echo $row["Address"]; ?></td>
		<td><?php echo $row["Email"]; ?></td>
		<td><?php echo $row["DistrictCode"]; ?></td>
		</tr>
		
		</table>
		
		
		<br/><br/>
		<?php
	}
}else{

	
   echo "0 reslut";
}

mysqli_close($conn);

?>
<?php

mysql_connect('localhost','root','');

mysql_select_db('lovelyhomes');
$id= $_POST['id'];
$sql="SELECT * FROM client";
$records=mysql_query($sql);
?>
<table width="600" border="1" cellspacing="1">
<tr><td><b> Customer ID</b></td><td><b> Customer Name</b></td><td><b>Contact No</b></td><td><b>Address</b></td><td><b>Email</b></td><td><b>District Code</td></tr>
<?php
while($order=mysql_fetch_assoc($records)){
	echo"<tr>";
	echo"<td>".$order['ClientID']."</td>";
	echo"<td>".$order['Client_FName']." ".$order['Client_LName']."</td>";
	echo"<td>".$order['Contact_No']."</td>";
	echo"<td>".$order['Address']."</td>";
	echo"<td>".$order['Email']."</td>";
	echo"<td>".$order['DistrictCode']."</td>";
	echo"</tr>";

	
}//end while
?>

