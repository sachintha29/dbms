<!DOCTYPEhtml >
<head>
<title>Order Management</title>
<link rel="stylesheet" type="text/css" href="designdata.css" />
</head>

<body>
    <header>
        <div class = "Heading"> <! Box containing the picture>

            <img src="lovelyhomes.jpg" style="vertical-align: middle" width= "100%" height="450px" />
            <p class="absolute_text">Lovely Homes</a></p>

    </header> </div>

    <div class="menu">  <! This is the box containing the menu>

            <aside><a href="../../Mainpage.php" target="_self"><font color="white">Home</font></a></aside>
            <aside><a href="../../About.php" target="_self"><font color="white">About</font></a></aside>
            <aside><a href="../../Contact.php" target="_self"><font color="white">Contact</font></a></aside>
		<aside><a href="../Admin.php" target="_self"><font color="white">Back</font></a></aside>
			<aside><a href="../Company/FurnitureStock.php" target="_self"><font color="white">Next</font></a></aside>
    </div>
    <br/>
    <br/>
<div class= "formorder"> <! This is the box containing the form and the navigation>

    <div class="content"><! This is the box containing the administrator and customer links>
            <div id="Navigation">
		
              
                   <h2><center><font size="5.5px"><u><b href="#" target="_self">Orders Page</b></font></center></h2>
				   <ul>
						<li><font size="5px">Orders of  Company</font></a></li>
					</ul>
				   




<h3><u>Find Order Details</u></h3>
<form name="frm1" action="find.php" method="post">
<div class= "formcontainer">
<fieldset>
<table>
<tr>
<td>Order ID</td><td><input type="text" name="id" placeholder="ex:1,2,3..."></td><td><input type="submit" name="sub" value="find" ></td>
</tr>
</table>
</fieldset>
</div>
</form>
<h3><u>Find Customer,Order Details</u></h3>
<form name="frm2" action="a.php" method="post">
<div class= "formcontainer">
<fieldset>
<table>
<tr>
<td>Customer ID</td><td><input type="text" name="id" placeholder="ex:1,2,3.."></td><td><input type="submit" name="sub" value="find" ></body></td>
</tr>
</table>
</fieldset>
</div>
</form>




<h3><u>Delete Order Details</u></h3>
<form name="frm4" action="delete.php" method="post">
<div class= "formcontainer">
<fieldset>
<table>
<tr>
<td>Order ID</td><td><input type="text" name="id" placeholder="ex:1,2,3..."></td><td><input type="submit" name="sub" value="delete" ></body></td>
</tr>
</table>
</fieldset>
</div>
</form>



<h3><u>Update Order Details</u></h3>

<fieldset>
<div class="formcontainer">
<table>
<form action="update.php" method="post">
<tr><td>Order  ID:</td><td><input type="text" name="id" /></td><td><input type="submit" name="text" value="update"></td></tr>
<tr><td>Customer ID:</td><td><input type="text" name="cid" /></td><td><input type="reset" name="reset" value="clear"></td></tr>
</form>

<form action="update2.php" method="post">
<tr><td>Order  ID:</td><td><input type="text" name="id" /></td><td><input type="submit" name="text" value="update"></td></tr>
<tr><td>FurnitureID</td><td><input type="text" name="fid" /></td><td><input type="reset" name="reset" value="clear"></td></tr>
</form>

<form action="update1.php" method="post">
<tr><td>Order  ID:</td><td><input type="text" name="id" /></td><td><input type="submit" name="text" value="update"></td></tr>
<tr><td>Quantity:</td><td><input type="text" name="quan" /></td><td><input type="reset" name="reset" value="clear"></td></tr>
</form>

<form action="update3.php" method="post">
<tr><td>Order  ID:</td><td><input type="text" name="id" /></td><td><input type="submit" name="text" value="update"></td></tr>
<tr><td>Delivery Date:</td><td><input type="date" name="date" /></td><td><input type="reset" name="reset" value="clear"></td></tr>
</form>

<form action="update4.php" method="post">
<tr><td>Order  ID:</td><td><input type="text" name="id" /></td><td><input type="submit" name="text" value="update"></td></tr>
<tr><td>Delivery status:</td><td><select name="choose">
<option></option><option>Yes</option><option>No</option></td><td><input type="reset" name="reset" value="clear"></td></tr>
</form>


</table>
</fieldset>
</div>
</form>
	   
		   
</body>
</html>