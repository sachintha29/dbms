<?php
$id= $_POST['id'];

include 'connection.php';

//Select Data
$sql1 ="SELECT * FROM companystock";
$sql ="SELECT * FROM companystock where Furniture_ID='$id'";
$result = mysqli_query($conn,$sql);

if(mysqli_num_rows($result)>0){
	//out put data of each row
	while($row =  mysqli_fetch_assoc($result)){
		?>
		
		<table align="center" border="1px">
		<tr><td><b> Furniture Name</b> </td><td><b>Unit Price</b></td><td><b>Available Quantity</b></td><td><b>District Code</b></td><b>Delivery status</b></td></tr>
		<tr><td><?php echo $row["furniture_Name"]; ?></td>
		<td><?php echo $row["Price"]; ?></td>
		<td><?php echo $row["Quantity"]; ?></td>
		<td><?php echo $row["DistrictCode"]; ?></td>
		
		</tr>
		
		</table>
		
		
		<br/><br/>
		<?php
	}
}else{

	
   echo "0 reslut";
}

mysqli_close($conn);

?>
<?php

mysql_connect('localhost','root','');

mysql_select_db('lovelyhomes');
$id= $_POST['id'];
$sql="SELECT * FROM companystock";
$records=mysql_query($sql);
?>
<h3>Furniture Stock Table</h3>
<table width="600" border="1" cellspacing="1">
<tr><td><b>Furniture ID</b> </td><td><b>Furniture Name</b></td><td><b>Description</b></td><td><b>Unit Price</b></td><td><b>Available Quantity</b></td>
<td><b>DistrictCode</b> </td>
</tr>
<?php
while($order=mysql_fetch_assoc($records)){
	echo"<tr>";
	echo"<td>".$order['Furniture_ID']."</td>";
	echo"<td>".$order['furniture_Name']."</td>";
	echo"<td>".$order['Description']."</td>";
	echo"<td>".$order['Price']."</td>";
	echo"<td>".$order['Quantity']."</td>";
	echo"<td>".$order['DistrictCode']."</td>";
	echo"</tr>";

	
}//end while
?>

