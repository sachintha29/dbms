<html>
<head><title>finding custermer details</title>

<link rel="stylesheet" type="text/css" href="designdata.css" />
</head>

<body>
    <header>
        <div class = "Heading"> <! Box containing the picture>

             <img src="" style="vertical-align: middle" width= "100%" height="80px" />
            <p class="absolute_text">Lovely Homes</a></p>

    </header> </div><b><h4>

    <div class="menu">  <! This is the box containing the menu>

            
            <aside><a href="../Mainpage.php" target="_self"><font color="white">Home</font></a></aside>
            <aside><a href="../About.php" target="_self"><font color="white">About</font></a></aside>
            <aside><a href="../Contact.php" target="_self"><font color="white">Contact</font></a></aside>
			<aside><a href="Ordermanage.php" target="_self"><font color="white">Back</font></a></aside>
			<aside><a href="Ordermanage.php" target="_self"><font color="white">Next</font></a></aside>
    </div>
	<body background="furniture.jpg">
	<div background color="white">
<?php
$id= $_POST['id'];

include 'connection.php';

//Select Data
$sql1 ="SELECT * FROM orders ";
$sql ="SELECT * FROM orders where OrderID='$id'";
$result = mysqli_query($conn,$sql);

if(mysqli_num_rows($result)>0){
	//out put data of each row
	while($row =  mysqli_fetch_assoc($result)){
		?>
		
		<table align="center" border="1px">
		<tr><td><b> FurnitureID</b> </td><td><b>ClientID</b></td><td><b>Quantity</b></td><td><b>Delivery Date</b></td><td><b>Delivery status</b></td></tr>
		<tr><td><?php echo $row["FurnitureID"]; ?></td>
		<td><?php echo $row["ClientID"]; ?></td>
		<td><?php echo $row["Quantity"]; ?></td>
		<td><?php echo $row["DeliveryDate"]; ?></td>
		<td><?php echo $row["Delivarystatus"]; ?></td>
		</tr>
		
		</table>
		
		
		<br/><br/>
		<?php
	}
}else{

	
   echo "0 reslut";
}

mysqli_close($conn);

?>
</div>
<?php

mysql_connect('localhost','root','');

mysql_select_db('lovelyhomes');
$id= $_POST['id'];
$sql="SELECT * FROM orders";
$records=mysql_query($sql);
?>
<table width="600" border="1" cellspacing="1">
<tr><td><b>Order ID</b> </td><td><b>Client ID</b></td><td><b>Furniture ID</b></td><td><b> Available Quantity</b></td><td><b>Delivary Date</b></td><td><b>Delivary Status</b></td></tr>
<?php
while($order=mysql_fetch_assoc($records)){
	echo"<tr>";
	echo"<td>".$order['OrderID']."</td>";
	echo"<td>".$order['ClientID']."</td>";
	echo"<td>".$order['FurnitureID']."</td>";
	echo"<td>".$order['Quantity']."</td>";
	echo"<td>".$order['DeliveryDate']."</td>";
	echo"<td>".$order['Delivarystatus']."</td>";
	echo"</tr>";

	
}//end while
?>
</h4></b>
</body>
