<!DOCTYPEhtml >
<head>
<title>Addminstrator Page</title>
<link rel="stylesheet" type="text/css" href="designdata.css" />
</head>

<body>
    <header>
        <div class = "Heading"> 

            <img src="lovelyhomes.jpg" style="vertical-align: middle" width= "100%" height="450px" />
            <p class="absolute_text">Lovely Homes</a></p>

    </header> </div>

    <div class="menu">  

            
            <aside><a href="../Mainpage.php" target="_self"><font color="white">Home</font></a></aside>
            <aside><a href="../About.php" target="_self"><font color="white">About</font></a></aside>
            <aside><a href="../Contact.php" target="_self"><font color="white">Contact</font></a></aside>
			<aside><a href="login.php" target="_self"><font color="white">Back</font></a></aside>
			<aside><a href="Admin.php" target="_self"><font color="white">Next</font></a></aside>
    </div>
    <br/>
    <br/>


    <div class="content">
            <div id="Navigation">
		
              
                   <h2><center><font size="5.5px"><u><b href="#" target="_self">Main Page</b></font></center></h2>
				   <ul>
						<li><font size="5px">Customer</font></a></li>
					</ul>
				   

</div>
<h3><u>Find Customer Details</u></h3>
<form name="frm1" action="customerfind.php" method="post">
<div class= "formcontainer">
<fieldset>
<table><h4>Enter Client ID</h4> 
<tr><td><input type="text" name="indx" value=""></td>
<td><input type="submit" name="sub" value="search" placeholder="Enter as 1,2"></td></tr>
</table></fieldset>
</div>
</form>

<form name="frm5" action="showall.php" method="post">
<input type="submit" name="sub" value="SEARCH ALL CUSTOMER Details">
</form>


<h3><u>Delete Customer Details</u></h3>
<form name="frm2" action="delete.php" method="post">
<div class= "formcontainer">
<fieldset>
<h4>ClientID</h4> 
<table><tr>
<td><input type="text" name="indx1"></td>
<td><input type="submit" name="sub" value="delete" placeholder="Enter as C001"></body></td></tr></table>
</fieldset>
</div>
</form>


<h3><u>Update Customer Details</u></h3>
<form name="frm3" action="update.php" method="post">
<fieldset><div class="formcontainer">
<table>
		<table align="left">
		<form action="update.php" method="post">
		<tr><td>CID</td><td><input type="text" id="txtno" name="txtno" /></td><td><input type="submit" value="update"></td></tr>
		
		<tr><td>First-Name </td> <td><input type="text" id="txtfn" name="txtfn" /></td><td><input type="reset" value="Clear"></td></tr>
		</form>
		<form action="update1.php" method="post">
		<tr><td>CID</td><td><input type="text" id="txtno" name="txtno" /></td><td><input type="submit" value="update"></td></tr>
		<tr><td>Last-Name </td>  <td><input type="text" id="txtln" name="txtln" /></td><td><input type="reset" value="Clear"></td></tr>
		</form>	
		<form action="update2.php" method="post">
		<tr><td>CID</td><td><input type="text" id="txtno" name="txtno" /></td><td><input type="submit" value="update"></td></tr>	
		<tr><td>Address </td><td><input type="text" id="address" name="address" /></td><td><input type="reset" value="Clear"></td></tr>
		</form>	
		<form action="update3.php" method="post">	
		<tr><td>CID</td><td><input type="text" id="txtno" name="txtno" /></td><td><input type="submit" value="update"></td></tr>	
		<tr><td>Email   </td><td><input type="email" id="email" name="email" /></td><td><input type="reset" value="Clear"></td></tr>
		</form>
		<br>
		<form action="update4.php" method="post">
		<tr><td>CID</td><td><input type="text" id="txtno" name="txtno" /></td><td><input type="submit" value="update"></td></tr>	
		<tr><td>Contact No </td> <td><input type="text" id="contact" name="contact" value=""></td><td><input type="reset" value="Clear"></td></tr>
		</form>
		
		<form action="update5.php" method="post">
	<tr><td>CID</td><td><input type="text" id="txtno" name="txtno" /></td><td><input type="submit" value="update"></td></tr>	
		<tr><td>District Code</td><td><input type="text" id="txtno" name="District" >
			<td><input type="reset" value="Clear"></td></tr>
				
			</form>
			<form name="frm5" action="showall.php" method="post">
<tr><input type="submit" name="sub" value="SEARCH ALL CUSTOMER Details">
</form></tr>
		</table>
		
		
		
		
		
		
		
		
		
		<table color="#334456" border="1" cellspacing="1" align="center">
			<tr><td>District </td><td> District Code</td></tr>
			<tr><td>Colombo</td><td>-01</td></tr>	
			<tr><td>Gampaha-</td><td>-02</td></tr>				
			<tr><td> Kaluthara</td><td>-03</td></tr>				
			<tr><td>Kandy</td><td>-04</td></tr>
			<tr><td> Mathara</td><td>-05</td></tr>
			<tr><td>Rathnapura</td><td>-06</td></tr>
			<tr><td>Galle</td><td>-07</td></tr>
			<tr><td>Anuradhapura</td><td>-08</td></tr>
			<tr><td>Polonnaruwa</td><td>-09</td></tr>
			<tr><td>Jaffna</td><td>-10</td></tr>				
		</table>

</div></fieldset>
</form>
<br>


<br>
<form>
<table>	
<a href="Orders/Ordermanage.php">

<ul>
	<li><font size="5px">Order details</font></li>
</ul>		   
</a>
   
   
   
  

<ul>
<a href="Company/FurnitureStock.php">


	<li><font size="5px">Furniture Stock details</font></li>
		   
</a></ul>

<a href="Showrooms/Showrooms.php">

<ul>
	<li><font size="5px">Show rooms details</font></li>
</ul>		   
</a>




<a href="Admin/newAdmin.php">

<ul>
	<li><font size="5px"> NewAdmin</font></li>
</ul>		   
</a>	
</table>		   
  <!--  </form>
	 <form action="../fdetails.php"      method="post">
	 <input type="submit" value="Show all furniture details">
	 
	 </form>
	  </form>
	 <form action="../showroomdetails.php"      method="post">
	 <input type="submit" value="Show all Showrooms details">
	 
	 </form>

</body>
</html>

