<!DOCTYPEhtml >
<head>
<title>Lovely homes</title>
<link rel="stylesheet" href="designdata.css" />
</head>

<body>

    <header>
        <div class = "Heading"> <! Box containing the picture>

            <img src="lovelyhomesfinalcropped.jpg" style="vertical-align: middle" width= "100%" height="450px" />
            <p class="absolute_text">Lovely Homes</a></p>

    </header> </div>

    <div class="menu">  <! This is the box containing the menu>

            <aside><a href="" target="_self"><font color="white">Home</font></a></aside>
            <aside><a href="About.php" target="_self"><font color="white">About</font></a></aside>
            <aside><a href="Contact.php" target="_self"><font color="white">Contact</font></a></aside>
    </div>


    <div class= "formorder"> <!-- This is the box containing the form and the navigation-->

    <div class="content"><!-- This is the box containing the administrator and customer links-->
           <div id="Navigation">
           <h2> To Customer</h2>
		   <ul>
              
                   <li><font size="5px"><b><a href="CusOrderform.php">Order</a> </b></font></li>
				   <li><b><font size="5px"><a href="customerdelivery.php">Delivery Details</a></b></font></li>
             </ul>
			<h2> To Adminstrator</h2>

			<ul>
                   <li><b><font size="5px"><a href="login/login.php">Administrator</a></b></font></li>
                   
           </ul>
		   </div>



     </div>   
   
<body>

