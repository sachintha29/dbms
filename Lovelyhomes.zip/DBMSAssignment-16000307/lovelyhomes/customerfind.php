<html>
<head><title></title></head>

<body>
    <header>
        <div class = "Heading"> <! Box containing the picture>

            
            <p class="absolute_text">Lovely Homes</a></p>
</div>
    </header> 

    <div class="menu">  <! This is the box containing the menu>

           
            <aside><a href="Mainpage.php" target="_self"><font color="white">Home</font></a></aside>
            <aside><a href="#" target="_self"><font color="white">About</font></a></aside>
            <aside><a href="#" target="_self"><font color="white">Contact</font></a></aside>
			<aside><a href="CusOrderform.php" target="_self"><font color="white">Back</font></a></aside>
			<aside><a href="CusOrderform.php" target="_self"><font color="white">Next</font></a></aside>
	
	</div>


<?php
$indx= $_POST['indx'];

include 'connection.php';

//Select Data
$sql1 ="SELECT * FROM client ";
$sql ="SELECT * FROM client where ClientID='$indx'";
$result = mysqli_query($conn,$sql);

if(mysqli_num_rows($result)>0){
	//out put data of each row
	while($row =  mysqli_fetch_assoc($result)){
		?>
		<table align="center" border="1px">
		<tr><td><b>CostomerID</td><td>First Name</td><td>Last Name</td><td>Contact No</td><td>Address</td><td>Email</td></b></tr>
		<tr><td><?php echo $indx; ?></td>
		<td><?php echo $row["Client_FName"]; ?></td>
		<td><?php echo $row["Client_LName"]; ?></td>
		<td><?php echo $row["Contact_No"]; ?></td>
		<td><?php echo $row["Address"]; ?></td>
		<td><?php echo $row["Email"]; ?></td></tr>	
		</table>
		
		
		<br/><br/>
		<?php
	}
}else{
   echo "0 reslut";
}

mysqli_close($conn);
?>