<!DOCTYPEhtml >
<head>
<title>Lovely homes</title>
<link rel="stylesheet" href="Aboutdetails.css" />
</head>

<body>
    <header>
        <div class = "Heading"> <! Box containing the picture>

            <img src="lovelyhomesfinalcropped.jpg" style="vertical-align: middle" width= "100%" height="450px" />
            <p class="absolute_text">Lovely Homes</a></p>

    </header> </div>

    <div class="menu">  <! This is the box containing the menu>

            <aside><a href="Mainpage.php" target="_self"><font color="white">Home</font></a></aside>
            <aside><a href="About.php" target="_self"><font color="white">About</font></a></aside>
            <aside><a href="Contact.php" target="_self"><font color="white">Contact</font></a></aside>
  
    </div>
    <br/>

    
    <br/>
    <br/>
    <br/>
    <br/>
    <div id = "Contentabout"> <! Div containing details about the company>

    <h2> About Us </h2>
    <p> 
    Lovely homes was a concept which was brought to life in  2004
as an initiative to transform the way Sri Lankans live and to bring it to the next level. 
Collaborating with many international designers to  create timeless designs , Lovely Homes is one of the 
best manufactures and designing companies  in Sri Lanka with nearly 13 years  of experience.
   </p>
   <p> At  Lovely homes , we believe that if you have an idea, we can make it a reality.With our range of varing collections
       whether it be traditional , modern or an infusion of both, we have what it takes to make your home the one you dream of.
       
   </p>

    </div> 

    <div id ="Images"> <!Dive containg the image on the side> 
    <img src="download.jpg" style="vertical-align: middle" width= "280px" height="100%" /> 
    </div> 

       
   
<body>

