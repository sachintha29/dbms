<!DOCTYPEhtml >
<head>
<title>Order Confirmation</title>
<link rel="stylesheet" href="designdata.css" />
</head>

<body>
    <header>
        <div class = "Heading"> <! Box containing the picture>

          <img src="" style="vertical-align: middle" width= "100%" height="80px" />
            <p class="absolute_text">Lovely Homes</a></p>

    </header> </div>

    <div class="menu">  <! This is the box containing the menu>

           
            <aside><a href="Mainpage.php" target="_self"><font color="white">Home</font></a></aside>
            <aside><a href="About.php" target="_self"><font color="white">About</font></a></aside>
            <aside><a href="Contact.php" target="_self"><font color="white">Contact</font></a></aside>
			<aside><a href="CusOrderform.php" target="_self"><font color="white">Back</font></a></aside>
			<aside><a href="CusOrderform.php" target="_self"><font color="white">Next</font></a></aside>
    </div>



<?php
		$eid=$_POST['cid'];
		$FID=$_POST['FurnitureID'];
		$Quantity=$_POST['code'];
		include'connection.php';
$sql1="INSERT INTO orders(ClientID,FurnitureID,Quantity) VALUES ('$eid','$FID','$Quantity')";
		if (mysqli_query($conn, $sql1)){
	echo "<h2><b>New record created successfully<br>We'll inform you about  your order</b></h2> ";
	
}else
	{
	echo"error:".$sql."<br>".$conn->error;
	}
	?>
	
<body>
<body background="furniture.jpg">
<br>

</body>
