<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <title>Login</title>
  
  
  
      <link rel="stylesheet" href="style.css">

  
</head>

<body>
  <html>
<head>
<meta charset="UTF-8">
<title>Sign In form</title>
<link rel="stylesheet" type="text/css" href="style.css">
<link href='https://fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
</head>

<body>
<body background=""
<div id="main" class="container"> 	
	<form name="Customer Delivery details" id="loginform" action="Deliverydetails.php" method="post" class="wpl-track-me"> 
		<p class="login-username">
		<label for="user_login">Client ID</label> 
			<input type="text" name="id" id="id" class="input" placeholder="Client ID" value="" size="20" /> 
		</p> 
		<p class="login-password"> 
		<label for="user_pass">OrderID</label><input type="text" name="my" id="id1" class="input" placeholder="Order ID" value="" size="20" /> 
		</p> 	
		
		<p class="login-submit"><input type="submit" name="wp-submit" id="wp-submit" class="button-primary" value="Check Order Status" />
		<input type="hidden" name="redirect_to" value="#"/>
		</p> 	
	</form> 
</div>
</body>
</html>
  
  
</body>
</html>
