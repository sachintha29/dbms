-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 06, 2017 at 07:06 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lovelyhomes`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `ID` int(11) NOT NULL,
  `username` varchar(24) NOT NULL,
  `password` varchar(24) NOT NULL,
  `levels` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- RELATIONS FOR TABLE `admin`:
--

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`ID`, `username`, `password`, `levels`) VALUES
(1, 'admin', '0000', 0),
(2, 'manager', '1234', 1),
(3, 'sales', '3456', 2);

-- --------------------------------------------------------

--
-- Table structure for table `client`
--

CREATE TABLE `client` (
  `ClientID` int(5) NOT NULL,
  `Client_FName` varchar(20) NOT NULL,
  `Client_LName` varchar(20) NOT NULL,
  `Contact_No` varchar(10) NOT NULL,
  `Address` varchar(70) NOT NULL,
  `Email` varchar(40) NOT NULL,
  `DistrictCode` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- RELATIONS FOR TABLE `client`:
--   `DistrictCode`
--       `showrooms` -> `Districtcode`
--

--
-- Dumping data for table `client`
--

INSERT INTO `client` (`ClientID`, `Client_FName`, `Client_LName`, `Contact_No`, `Address`, `Email`, `DistrictCode`) VALUES
(1, 'Hashini', 'jayathilaka', '0112800945', 'no:210,galle fort,galle', 'hjaya@gmail.com', 5),
(2, 'Suriyasiri', 'perera', '0112752133', 'no 30,homagama', 'lahiru@gmail.com', 1),
(3, 'lahiru', 'perera', '0112700300', 'No:14,mawanalla', 'milla@gmail.com', 4),
(4, 'vijadasa', 'premasiri', '0112500300', 'no:10,walasmula', 'premasri@gmail.com', 7),
(6, 'sadun', 'wedage', '0112300400', 'no:300/1,kandy road,kandy', 'sadunwe@gmail.com', 4),
(8, 'kumari', 'soysa', '0112300489', 'No:234,galle.', 'kumari@gmail.com', 7),
(10, 'kaveesha', 'Mihirangi', '0155686666', 'Mirissa, Matara', 'mihirangi@gmail.com', 5);

-- --------------------------------------------------------

--
-- Table structure for table `companystock`
--

CREATE TABLE `companystock` (
  `Furniture_ID` varchar(6) NOT NULL,
  `furniture_Name` varchar(20) NOT NULL,
  `Description` varchar(100) NOT NULL,
  `Price` decimal(10,2) NOT NULL,
  `Quantity` varchar(4) NOT NULL,
  `DistrictCode` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

--
-- RELATIONS FOR TABLE `companystock`:
--   `DistrictCode`
--       `showrooms` -> `Districtcode`
--   `DistrictCode`
--       `showrooms` -> `Districtcode`
--

--
-- Dumping data for table `companystock`
--

INSERT INTO `companystock` (`Furniture_ID`, `furniture_Name`, `Description`, `Price`, `Quantity`, `DistrictCode`) VALUES
('F0001', 'Writing Table', 'For Office\nSizes- small ,color can  be selected', '25000.00', '120', 1),
('F0002', 'bed', 'black or brown headboard.', '50000.00', '150', 1),
('F0003', 'bed', 'black or brown heaboard', '50000.00', '150', 5),
('F0004', 'table', 'black or brown\nlarge', '35000.00', '40', 5),
('F0005', 'chair', 'black', '9000.00', '50', 7),
('F0006', 'Grandfather clock', 'Vintage, black', '15000.00', '50', 4),
('F0007', 'Sofa', 'Medium\r\nYou Can select Colors', '100000.00', '20', 4);

-- --------------------------------------------------------

--
-- Table structure for table `detailsofstock`
--

CREATE TABLE `detailsofstock` (
  `DistrictCode` int(3) NOT NULL,
  `FurnitureID` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- RELATIONS FOR TABLE `detailsofstock`:
--   `DistrictCode`
--       `showrooms` -> `Districtcode`
--   `FurnitureID`
--       `companystock` -> `Furniture_ID`
--   `FurnitureID`
--       `companystock` -> `Furniture_ID`
--   `DistrictCode`
--       `showrooms` -> `Districtcode`
--

--
-- Dumping data for table `detailsofstock`
--

INSERT INTO `detailsofstock` (`DistrictCode`, `FurnitureID`) VALUES
(1, 'F0001'),
(1, 'F0002'),
(4, 'F0004'),
(4, 'F0006'),
(4, 'F0007'),
(5, 'F0003'),
(7, 'F0005');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `OrderID` int(4) NOT NULL,
  `ClientID` int(5) NOT NULL,
  `FurnitureID` varchar(6) NOT NULL DEFAULT '',
  `Quantity` int(3) NOT NULL,
  `DeliveryDate` date NOT NULL,
  `Delivarystatus` varchar(10) NOT NULL DEFAULT 'YES/NO'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- RELATIONS FOR TABLE `orders`:
--   `FurnitureID`
--       `companystock` -> `Furniture_ID`
--   `ClientID`
--       `client` -> `ClientID`
--

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`OrderID`, `ClientID`, `FurnitureID`, `Quantity`, `DeliveryDate`, `Delivarystatus`) VALUES
(2, 3, 'F0001', 20, '2017-01-01', 'Yes'),
(3, 1, 'F0003', 10, '2017-01-21', 'Yes'),
(4, 2, 'F0001', 30, '2017-01-20', 'Yes'),
(5, 3, 'F0001', 20, '2017-01-31', 'Yes'),
(8, 4, 'F0007', 20, '2017-05-28', 'YES'),
(10, 6, 'F0005', 1, '0000-00-00', 'NO'),
(13, 1, 'F0001', 3, '2017-10-05', 'No'),
(15, 10, 'F0003', 3, '0000-00-00', 'YES/NO');

-- --------------------------------------------------------

--
-- Table structure for table `showrooms`
--

CREATE TABLE `showrooms` (
  `Districtcode` int(3) NOT NULL,
  `District` varchar(20) NOT NULL,
  `Address` varchar(60) NOT NULL,
  `Telephone` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- RELATIONS FOR TABLE `showrooms`:
--

--
-- Dumping data for table `showrooms`
--

INSERT INTO `showrooms` (`Districtcode`, `District`, `Address`, `Telephone`) VALUES
(1, 'Colombo', 'No 32, Dawson Street, Colombo 5', '0110254867'),
(4, 'Kandy', 'No 71, Hill Street, Kandy  ', '0113694768'),
(5, 'Mathara ', 'No 35, Jayasinghe Road, Hiththatiya. ', '0112358648'),
(7, 'Galle', ' No 53, A.R. Wijewardene Mawatha ', '0113259667');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`ClientID`),
  ADD KEY `first` (`DistrictCode`);

--
-- Indexes for table `companystock`
--
ALTER TABLE `companystock`
  ADD PRIMARY KEY (`Furniture_ID`),
  ADD KEY `second` (`DistrictCode`);

--
-- Indexes for table `detailsofstock`
--
ALTER TABLE `detailsofstock`
  ADD PRIMARY KEY (`DistrictCode`,`FurnitureID`),
  ADD KEY `Furniture` (`FurnitureID`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`OrderID`),
  ADD KEY `stock` (`FurnitureID`),
  ADD KEY `third` (`ClientID`);

--
-- Indexes for table `showrooms`
--
ALTER TABLE `showrooms`
  ADD PRIMARY KEY (`Districtcode`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `client`
--
ALTER TABLE `client`
  MODIFY `ClientID` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `OrderID` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `showrooms`
--
ALTER TABLE `showrooms`
  MODIFY `Districtcode` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `client`
--
ALTER TABLE `client`
  ADD CONSTRAINT `first` FOREIGN KEY (`DistrictCode`) REFERENCES `showrooms` (`Districtcode`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `companystock`
--
ALTER TABLE `companystock`
  ADD CONSTRAINT `second` FOREIGN KEY (`DistrictCode`) REFERENCES `showrooms` (`Districtcode`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `detailsofstock`
--
ALTER TABLE `detailsofstock`
  ADD CONSTRAINT `Furniture` FOREIGN KEY (`FurnitureID`) REFERENCES `companystock` (`Furniture_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `district` FOREIGN KEY (`DistrictCode`) REFERENCES `showrooms` (`Districtcode`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `stock` FOREIGN KEY (`FurnitureID`) REFERENCES `companystock` (`Furniture_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `third` FOREIGN KEY (`ClientID`) REFERENCES `client` (`ClientID`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
