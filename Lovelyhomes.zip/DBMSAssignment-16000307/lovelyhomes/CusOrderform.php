<!DOCTYPEhtml >
<head>
<title>Lovely homes</title>
<link rel="stylesheet" href="designdata.css" />
</head>

<body>
    <header>
        <div class = "Heading"> <! Box containing the picture>

            <img src="lovelyhomesfinalcropped.jpg" style="vertical-align: middle" width= "100%" height="450px" />
            <p class="absolute_text">Lovely Homes</a></p>

    </header> </div>

    <div class="menu">  <! This is the box containing the menu>

           
            <aside><a href="Mainpage.php" target="_self"><font color="white">Home</font></a></aside>
            <aside><a href="About.php" target="_self"><font color="white">About</font></a></aside>
            <aside><a href="Contact.php" target="_self"><font color="white">Contact</font></a></aside>
			<aside><a href="Mainpage.php" target="_self"><font color="white">Back</font></a></aside>
			
    </div>
    <br/>
    <br/>
<div class= "formorder"> <! This is the box containing the form and the navigation>

    <div class="content"><! This is the box containing the administrator and customer links>
           <div id="Navigation">
		<ul>
              
                   <li><b href="#" target="_self">Customer</b></li>
             
                   
                   
               	</ul>    
           </div>
<form method="post" action="addCustomer.php">
            <div class= "formcontainer"> <!Box containing the form  >
           <fieldset>
               <legend><h4>Customer Information form</h4></legend>
               <br/>
               <br/>
			   <table>
				<tr><td>First Name   =</td><td><input name="firstname" type="text" size="30" value="" placeholder="Enter First Name" />
                </td></tr>
                <tr><td>Last Name    =</td><td><input name="lastname" type="text" size="30"  value="" placeholder="Enter Last Name"/>
                </td></tr>
				<tr><td>Address      =</td><td><input name="adderss" type="text" value="" placeholder="Enter Address"/>
                </td></tr>
                <tr><td>Email        =</td><td><input name="emailaddress" type="email" value="" placeholder="Enter Email"/>
                </td></tr>
				<tr><td>Contact NO   =</td><td><input name="number" type="tel" value="" placeholder="Enter Telephone Number"/>
                </td></tr>
				<tr><td>District code=</td><td><select name="district"><option></option>
				<option>01</option><option>02</option><option>03</option><option>04</option><option>05</option>
				<option>06</option><option>07</option><option>08</option><option>09</option><option>10</option>
				</select><td></tr></table>
				<table color="#334456" border="1" cellspacing="1">
<tr><td>District </td><td> District Code</td></tr>
<tr><td>Colombo</td><td>-01</td></tr>	
<tr><td>Gampaha-</td><td>-02</td></tr>				
<tr><td> Kaluthara</td><td>-03</td></tr>				
<tr><td>Kandy</td><td>-04</td></tr>
<tr><td> Mathara</td><td>-05</td></tr>
<tr><td>Rathnapura</td><td>-06</td></tr>
<tr><td>Galle</td><td>-07</td></tr>
<tr><td>Anuradhapura</td><td>-08</td></tr>
<tr><td>Polonnaruwa</td><td>-09</td></tr>
<tr><td>Jaffna</td><td>-10</td></tr>				
</table>
				
				<input type="submit" value="CONFIRM">
			 <input name="reset" type="reset" value="Clear">
          
			  </form>
           </fieldset><fieldset><form align="center" action="showroomdetails.php">
<input type="submit" value="Show rooms details">

</form></fieldset>
        <div/>
    <form action="w.php" method="post"><fieldset>
   First Name<input name="name1" type="text" size="30" value="" placeholder="Enter First Name Again" />
   Last Name<input name="name2" type="text" size="30"  value="" placeholder="Enter Last Name Agin"/> <br><input type="submit"  value="get your ID"/> 
</fieldset></form>
            <form action="fdetails.php" method="post"><center><h3><input type="submit" value="See furniture details"><h3><center></form>		

   
            <div class= "formcontainer"> <!Box containing the form  >
           <fieldset>
               <legend><h4>Customer Order form</h4></legend>
               <br/>
               <br/>
			 <form action="ordersconfrim.php" method="post">
			  <table>
			  <tr><td>CID=</td><td><input name="cid" type="int"   placeholder="Enter customerid"/>
               </td></tr>
			  <tr><td>Quantity=</td><td><input name="code" type="int"   placeholder="Enter Quantity"/>
               </td></tr>
			<tr><td>FurnitureID=</td><td><input name="FurnitureID" type="text"  placeholder="(type=[F0___])"/>
               </td></tr></table>
               <input type="submit" value="CONFIRM">
                
				
           </fieldset>
        <div/>
		</form>
    </div>
	<form action="a.php" method="post">
	<table>
	<tr>CID<input name="cidu" type="text" placeholder="ex 1,2,3"></tr>
	</table>

<input type="submit" value="To see you detail and ID">
</form>



</html>
