<!DOCTYPEhtml >
<head>
<title>Delivary Details</title>
<link rel="stylesheet" href="designdata.css" />
</head>

<body>

    <header>
        <div class = "Heading"> <! Box containing the picture>

            <img src="img/lovelyhomes.jpg" style="vertical-align: middle" width= "100%" height="450" />
            <p class="absolute_text">Lovely Homes</a></p>

    </header> </div>

    <div class="menu">  <! This is the box containing the menu>

            <aside><a href="Mainpage.php" target="_self"><font color="white">Home</font></a></aside>
            <aside><a href="About.php" target="_self"><font color="white">About</font></a></aside>
            <aside><a href="Contact.php" target="_self"><font color="white">Contact</font></a></aside>
			<aside><a href="Mainpage.php" target="_self"><font color="white">Back</font></a></aside>
    </div>
    <br/>
    <br/>
<div background color="white">
<?php


$id=$_POST['id'];
$id1=$_POST['my'];

include 'connection.php';

//Select Data
$sql1 ="SELECT * FROM client ";
$sql ="SELECT * FROM orders WHERE  ClientID='$id' AND OrderID='$id1'";
$result = mysqli_query($conn,$sql);

if(mysqli_num_rows($result)>0){
	//out put data of each row
	while($row =  mysqli_fetch_assoc($result)){
		?>
		<body>
<h2>Customer Details</h2>
<table border="1px">
<tr><td><b>Your ID</b></td>
	<td><b>OrderID</b></td>	
	<td><b>FurnitureID</b></td>	
    <td><b>Delivery Date</b></td>
	<td><b>Delivery Status(yes/no)</b></td>
	</tr>

		
		<tr><td><?php echo $row["ClientID"];?></td>
		<td><?php echo $row["OrderID"]; ?></td>
		<td><?php echo $row["FurnitureID"];?></td>
		<td><?php echo $row["DeliveryDate"];?></td>
		<td><?php echo $row["Delivarystatus"];?></td>
		</tr>
		
		</table>
		
		
		<br/><br/>
		<?php
	}
}else{
   echo "<br>No result";
}

mysqli_close($conn);
?>
</div>
</body></html>