<?php
$indx= $_POST['indx'];

include 'connection.php';

//Select Data
$sql1 ="SELECT * FROM client ";
$sql ="SELECT * FROM client where ClientID='$indx'";
$result = mysqli_query($conn,$sql);

if(mysqli_num_rows($result)>0){
	//out put data of each row
	while($row =  mysqli_fetch_assoc($result)){
		?>
		<?php echo $indx; ?><br/>
		<?php echo $row["stdname"]; ?><br/>
  		<?php
	}
}else{
   echo "0 reslut";
}

mysqli_close($conn);
?>