<?php
$servername = "localhost";
$username = "username";
$password = "password";

try {
    $conn = new PDO("mysql:host=$servername;dbname=lovelyhomes", $username, $password);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "Connected successfully"; 
    }
catch(PDOException $e)
    {
    echo "Connection failed: " . $e->getMessage();
    }
?>

<!DOCTYPEhtml >
<head>
<title>Lovely homes</title>
<link rel="stylesheet" href="designdata.css" />
</head>

<body>
    <header>
        <div class = "Heading"> <! Box containing the picture>

            <img src="headimages.jpg" style="vertical-align: middle" width= "100%" height="400px" />
            <p class="absolute_text">Lovely Homes</a></p>

    </header> </div>

    <div class="menu">  <! This is the box containing the menu>

            <aside><a href="#" target="_self"><font color="white">Home</font></a></aside>
            <aside><a href="#" target="_self"><font color="white">About</font></a></aside>
            <aside><a href="#" target="_self"><font color="white">Contact</font></a></aside>
    </div>
    <br/>
    <br/>
<div class= "formorder"> <! This is the box containing the form and the navigation>

    <div class="content"><! This is the box containing the administrator and customer links>
           <div id="Navigation">
		<ul>
              
                   <li><b href="#" target="_self">Order </b></li>
             
                   
                   
               	</ul>    
           </div>
<form>
            <div class= "formcontainer"> <!Box containing the form  >
           <fieldset>
               <legend><h4>Order form</h4></legend>
               <br/>
               <br/><table>
                <tr><td>First Name=</td><td><input name="firstname" type="text" size="30" value="" placeholder="Enter First Name" />
                </td></tr>
                <tr><td>Last Name=</td><td><input name="lastname" type="text" size="30"  value="" placeholder="Enter Last Name"/>
                </td></tr>
                <tr><td>Email Address=</td><td><input name"emailaddress" type="email" value="" placeholder="Enter Email"/>
                </td></tr>
                <tr><td>Product code=</td><td><input name="code" type="text" value="" placeholder="Enter Code of Product" />
                </td></tr>
                <tr><td>Quantity=</td><td><input name="code" type="number" value="" placeholder="Enter Quantity" />
                </td></tr>
                <tr><td>Contact Number=</td><td><input name"number" type="tel" value="" placeholder="Enter Telephone Number"/>
                </td></tr>
                </table>
           </fieldset>
        <div/>
    

              <input type="submit" value="Submit">
       </form>
    </div>
</body>
</html>

