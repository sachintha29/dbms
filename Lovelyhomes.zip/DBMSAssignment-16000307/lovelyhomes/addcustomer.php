<head>
<title>ConFirm Customer</title>
<link rel="stylesheet" href="designdata.css" />
</head>

<body>
    <header>
        <div class = "Heading"> <! Box containing the picture>

             <img src="" style="vertical-align: middle" width= "100%" height="80px" />
            <p class="absolute_text">Lovely Homes</a></p>
</div>
    </header> 

    <div class="menu">  <! This is the box containing the menu>

           
            <aside><a href="Mainpage.php" target="_self"><font color="white">Home</font></a></aside>
            <aside><a href="#" target="_self"><font color="white">About</font></a></aside>
            <aside><a href="#" target="_self"><font color="white">Contact</font></a></aside>
			<aside><a href="CusOrderform.php" target="_self"><font color="white">Back</font></a></aside>
			<aside><a href="CusOrderform.php" target="_self"><font color="white">Next</font></a></aside>
	</div>

<br>
<br><h2><center>
<?php
		
		$fname=$_POST['firstname'];
		$lname=$_POST['lastname'];
		$address1=$_POST['adderss'];
		$email=$_POST['emailaddress'];
		$phone=$_POST['number'];
		$district=$_POST['district'];
		include'connection.php';

		$sql="INSERT INTO client (Client_FName,Client_LName,Address,Email,Contact_No,DistrictCode) VALUES ('$fname','$lname','$address1','$email','$phone','$district')";
		if (mysqli_query($conn, $sql)){
	echo "<br><b>New record created successfully</b>";
}else
	{
	echo"error:".$sql."<br>".$conn->error;
	}
?>		
		
	
	<br> Click next to give Order details</h2><center>
<body background="furniture.jpg">


</body></html>