<html>
</head><title>Getting  Customer details </title></head>
<link rel="stylesheet" href="designdata.css" />
</head>

<body>
    <header>
        <div class = "Heading"> <! Box containing the picture>

             <img src="" style="vertical-align: middle" width= "100%" height="80px" />
            <p class="absolute_text">Lovely Homes</a></p>
</div>
    </header> 

    <div class="menu">  <! This is the box containing the menu>

           
            <aside><a href="Mainpage.php" target="_self"><font color="white">Home</font></a></aside>
            <aside><a href="#" target="_self"><font color="white">About</font></a></aside>
            <aside><a href="#" target="_self"><font color="white">Contact</font></a></aside>
			<aside><a href="CusOrderform.php" target="_self"><font color="white">Back</font></a></aside>
			<aside><a href="CusOrderform.php" target="_self"><font color="white">Next</font></a></aside>
			</div>
	<br><br><h2>
	<style>
	div.my {
    background-color: white;
    color: black;
    margin: 20px 0 20px 0;
    padding: 20px;
}
</style>
<div class="my">	
<?php


$id=$_POST['cidu'];

include 'connection.php';

//Select Data
$sql1 ="SELECT * FROM client ";
$sql ="SELECT * FROM client,orders WHERE client.ClientID=orders.ClientID AND client.ClientID='$id'";
$result = mysqli_query($conn,$sql);

if(mysqli_num_rows($result)>0){
	//out put data of each row
	while($row =  mysqli_fetch_assoc($result)){
		?>
		<body>
<h2>Customer Details</h2>
<table border="1px">
<tr><td><b>Your ID</b></td>
	<td><b>OrderID</b></td>	
	<td><b>	FurnitureID</b></td>
	
	<td><b>	Customer Name</b></td>
		<td><b>Contact no:</b></td>
	<td><b>	Address</b></td>
	<td><b>DistrictCode</b></td>	
	<td><b>Quantity </b></td> 
	<td><b>Email </b></td> 
	<td><b>Contact No </b></td>
    </tr>

		
		<tr><td><?php echo $row["ClientID"] ?></td>
		<td><?php echo $row["OrderID"]; ?></td>
		<td><?php echo $row["FurnitureID"]; ?></td>
		<td><?php echo $row["Client_FName"]; ?>  <?php echo $row["Client_LName"];?></td>
		<td><?php echo $row["Contact_No"]; ?></td>
		<td><?php echo $row["Address"]; ?></td>
		<td><?php echo $row["DistrictCode"]; ?></td>
		<td><?php echo $row["Quantity"]; ?></td>
		<td><?php echo $row["Email"]; ?></td>
		<td><?php echo $row["Contact_No"]; ?></td></tr>
		
		</table>
		
		
		<br/><br/>
		<?php
	}
}else{
   echo "0 reslut";
}

mysqli_close($conn);
?>
</div>
</hr>
<body background="furniture.jpg">

<br>


</h3>
</body>
	