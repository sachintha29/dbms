<!DOCTYPEhtml >
<head>
<title>Show rooms details </title>
<link rel="stylesheet" href="designdata.css" />
</head>

<body>
    <header>
        <div class = "Heading"> <! Box containing the picture>

            <img src="" style="vertical-align: middle" width= "100%" height="80px" />
            <p class="absolute_text">Lovely Homes</a></p>

    </header> </div>

    <div class="menu">  <! This is the box containing the menu>

           
            <aside><a href="Mainpage.php" target="_self"><font color="white">Home</font></a></aside>
            <aside><a href="About.php" target="_self"><font color="white">About</font></a></aside>
            <aside><a href="Contact.php" target="_self"><font color="white">Contact</font></a></aside>
			<aside><a href="Mainpage.php" target="_self"><font color="white">Back</font></a></aside>
			<aside><a href="CusOrderform.php" target="_self"><font color="white">Next</font></a></aside>
    </div>


<?php

mysql_connect('localhost','root','');

mysql_select_db('lovelyhomes');
$sql="SELECT * FROM showrooms";
$records=mysql_query($sql);
?>

<body>
<body background="furniture.jpg">
<style>
	div.my {
    background-color: white;
    color: black;
	margin:40px 0 40px;
    padding: 20px;
}
</style>
<div background-color="#ffffff">
<table width="600" border="1" cellspacing="1" align="left">
 
<tr><td><b>District Code</b> </td><td><b>District</b><td><b>Showroom Address</b></td><td><b>Telephone</b></td></tr>
<?php
while($showroom=mysql_fetch_assoc($records)){
	echo"<tr>";
	echo"<td>".$showroom['Districtcode']."</td>";
	echo"<td>".$showroom['District']."</td>";
	echo"<td>".$showroom['Address']."</td>";
	echo"<td>".$showroom['Telephone']."</td>";
	echo"</tr>";

	
}//end while
?>
</table>
</div>

<br><br><br>



</body>
</html>