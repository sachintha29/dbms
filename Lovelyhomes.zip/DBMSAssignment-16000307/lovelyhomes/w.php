<html>
</head><title>Getting  Customer details </title></head>
<link rel="stylesheet" href="designdata.css" />
</head>

<body>
    <header>
        <div class = "Heading"> <! Box containing the picture>

              <img src="" style="vertical-align: middle" width= "100%" height="80px" />
            <p class="absolute_text">Lovely Homes</a></p>
</div>
    </header> 

    <div class="menu">  <! This is the box containing the menu>

           
            <aside><a href="Mainpage.php" target="_self"><font color="white">Home</font></a></aside>
            <aside><a href="#" target="_self"><font color="white">About</font></a></aside>
            <aside><a href="#" target="_self"><font color="white">Contact</font></a></aside>
			<aside><a href="CusOrderform.php" target="_self"><font color="white">Back</font></a></aside>
			<aside><a href="CusOrderform.php" target="_self"><font color="white">Next</font></a></aside>
	
	</div>
	<style>
	div.my {
    background-color: white;
    color: black;
    margin: 20px 0 20px 0;
    padding: 20px;
}
</style>
	<div class="my" >
<?php
$indx= $_POST['name1'];
$indx1= $_POST['name2'];
include 'connection.php';

//Select Data
$sql1 ="SELECT * FROM client ";
$sql ="SELECT * FROM client WHERE Client_FName='$indx' AND Client_LName='$indx1' ";
$result = mysqli_query($conn,$sql);

if(mysqli_num_rows($result)>0){
	//out put data of each row
	while($row =  mysqli_fetch_assoc($result)){
		?>
		<body>
<h2>Customer Details</h2>
		<table border="1px">
		<tr><td><b>CustomerID</td><td>First Name</td><td>Last Name</td><td>Contact No</td><td>Address</td><td>Email</td><td>District Code</td></b></tr>
		<tr><td><?php echo $row['ClientID'];?></td>
		<td><?php echo $row["Client_FName"]; ?></td>
		<td><?php echo $row["Client_LName"]; ?></td>
		<td><?php echo $row["Contact_No"]; ?></td>
		<td><?php echo $row["Address"]; ?></td>
		<td><?php echo $row["Email"]; ?></td>
		<td><?php echo $row["DistrictCode"]; ?></td></tr>
		</table>
		
		
		<br/><br/>
		<?php
	}
}else{
   echo "0 reslut";
}

mysqli_close($conn);
?>

<?php
$indx= $_POST['name1'];
$indx1= $_POST['name2'];
include 'connection.php';

//Select Data
$sql1 ="SELECT * FROM client ";
$sql ="SELECT * FROM client WHERE Client_FName='$indx' AND Client_LName='$indx1' ";
$result = mysqli_query($conn,$sql);

if(mysqli_num_rows($result)>0){
	//out put data of each row
	while($row =  mysqli_fetch_assoc($result)){
		?>
		<body>
<h1>Remember Your Customer ID</h1>
		<table border="1px" cellspacing="10px" cellpadding="10px">
		<tr><td align="center"><b><h2>CustomerID</h2></td><!--<td>First Name</td><td>Last Name</td><td>Contact No</td><td>Address</td><td>Email</td><td>District Code</td></b>-->
		<td align="center"><h2><?php echo $row['ClientID'];?></h2></td>
		<!--<td><?php echo $row["Client_FName"]; ?></td>
		<td><?php echo $row["Client_LName"]; ?></td>
		<td><?php echo $row["Contact_No"]; ?></td>
		<td><?php echo $row["Address"]; ?></td>
		<td><?php echo $row["Email"]; ?></td>
		<td><?php echo $row["DistrictCode"]; ?></td>-->
		</tr>
		</table>
		
		
		<br/><br/>
		<?php
	}
}else{
   echo "0 reslut";
}

mysqli_close($conn);
?>
</div>
<body background="furniture.jpg">
</body>

<br>

</font>

</h3>
</body>














	