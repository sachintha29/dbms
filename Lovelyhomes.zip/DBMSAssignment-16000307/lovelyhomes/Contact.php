<!DOCTYPEhtml >
<head>
<title>Lovely homes</title>
<link rel="stylesheet" href="Contact.css" />
</head>

<body>
    <header>
        <div class = "Heading"> <! Box containing the picture>

            <img src="lovelyhomesfinalcropped.jpg" style="vertical-align: middle" width= "100%" height="450px" />
            <p class="absolute_text">Lovely Homes</a></p>

    </header> </div>

    <div class="menu">  <! This is the box containing the menu>

          <aside><a href="Mainpage.php" target="_self"><font color="white">Home</font></a></aside>
            <aside><a href="About.php" target="_self"><font color="white">About</font></a></aside>
            <aside><a href="Contact.php" target="_self"><font color="white">Contact</font></a></aside>
    </div>
    <br/>
    <br/>
    <br/>
    <br/>


    <div id= "Contactdetails"> <! This is the box containing the details >
    <h1>Email Us <br><center>   lovelyhomes@gmail.com</center></h1>
	<h2> Contact Us </h2>
    <p>Have any inquiries regarding our products ?  Feel free to contact us or to visit any of our branches. </p>
    <br/>
    <p>Lovely Homes-Colombo</p>
    <p>No 32, Dawson Street, Colombo 5</p>
    <p>Hotline-0110254867</p>
    <br/>
    <br/>
    <p>Lovely Homes -Galle</p>
    <p>No 53, A.R. Wijewardene Mawatha .</p>
    <p>Hotline - 0113259667</p>
    
    <br/>
    <br/>

    <p>Lovely Homes- Kandy</p>
    <p>No 71, Hill Street, Kandy</p>
    <p>Hotline - 0113694768</p>
   
    <br/>
    <br/>
    <p>Lovely Homes - Mathara</p>
    <p>No 35, Jayasinghe Road, Hiththatiya.</p>
    <p>Hotline - 0112358648</p>
    

     
     </div>

     <div id ="Images"> <!Div containg the image on the side>
         <img src="contactimage.jpg" style="vertical-align: middle" width= "280px" height="200px" /> 
     </div>

     <div id ="Images2"> <!Div containg the image on the side>
         <img src="contactimage2.jpg" style="vertical-align: middle" width= "280px" height="200px" /> 
     </div>
    
    <div id ="Images3"> <!Div containg the image on the side>
         <img src="contactimage3.jpg" style="vertical-align: middle" width= "280px" height="200px" /> 
     </div>
    
       
   
<body>

